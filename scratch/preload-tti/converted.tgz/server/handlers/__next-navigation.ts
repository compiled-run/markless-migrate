// next/navigation's notFound() and redirect(), as the old route handlers call them.
export class NavigationThrow extends Error {
	constructor(readonly status: number, readonly location?: string) {
		super(location ? `redirect ${location}` : 'not found');
	}
}
export function notFound(): never {
	throw new NavigationThrow(404);
}
export function redirect(url: string): never {
	throw new NavigationThrow(307, url);
}
export function permanentRedirect(url: string): never {
	throw new NavigationThrow(308, url);
}
