// next/server's NextResponse and NextRequest, as the old route handlers use them, on the Fetch API.
export class NextResponse extends Response {
	static json(body: unknown, init?: ResponseInit): Response {
		return Response.json(body, init);
	}
	static redirect(url: string | URL, status = 307): Response {
		return Response.redirect(url, status);
	}
}
export type NextRequest = Request & { readonly nextUrl: URL };
export function nextRequest(request: Request): NextRequest {
	return Object.assign(request, { nextUrl: new URL(request.url) }) as NextRequest;
}
// after(): the callback runs once the response is handed back.
export function after(callback: () => unknown): void {
	setTimeout(() => void Promise.resolve().then(callback).catch(() => {}), 0);
}
